# Clínica Spa Viessence

Site da Clínica Spa Viessence — massagem relaxante, terapêutica e aromaterapia.

Projeto em um único arquivo HTML (`index.html`), sem dependências para instalar.
As imagens estão embutidas no próprio arquivo; só as fontes vêm do Google Fonts.

## Como publicar no GitHub Pages

1. No GitHub, crie um repositório novo (ex.: `viessence`).
2. Clique em **Add file → Upload files** e envie o `index.html` e este `README.md`.
3. Clique em **Commit changes**.
4. Vá em **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`. Salve.
6. Em alguns minutos o site fica no ar em `https://SEU-USUARIO.github.io/viessence/`.

## Antes de divulgar

- Os botões de WhatsApp usam `https://wa.me/?text=...` **sem número**. Troque por `https://wa.me/55DDDNUMERO?text=...` (código do país + DDD + número, só dígitos).
- Os links de Instagram, Facebook e TikTok no rodapé apontam para as páginas iniciais das redes. Troque pelos perfis da clínica.

## Sobre o nome do arquivo

`spa-IndexHTML.html` é uma cópia idêntica do `index.html`.
O GitHub Pages abre sozinho o arquivo chamado `index.html`. Se usar só o `spa-IndexHTML.html`, o endereço do site terá que terminar com `/spa-IndexHTML.html`.
